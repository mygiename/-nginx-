from django.db import models

# Create your models here.

# 个人信息
class UserInfo(models.Model):
    username=models.CharField(verbose_name='用户名',max_length=30,primary_key=True)
    password=models.CharField(verbose_name='密码',max_length=32)
    nickname=models.CharField(verbose_name='昵称',max_length=20)
    grade=models.CharField(verbose_name='年级',max_length=20)
    age=models.IntegerField(verbose_name='年龄',default=100)
    img=models.ImageField(verbose_name='图片')
    regist_time=models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table='user_info'

# 任务表
class Task(models.Model):
    task_name=models.CharField(verbose_name='任务名称',max_length=50)
    task_describe=models.CharField(verbose_name='任务描述',max_length=200)
    task_type=models.CharField(verbose_name='任务类型',max_length=10)
    release_time = models.DateTimeField(verbose_name='发布时间',auto_now=True)
    receive_time_limit = models.DateTimeField(verbose_name='完成任务时间',auto_now=True)
    # 联系qq
    contact_qq=models.IntegerField(verbose_name='QQ')
    receiver=models.CharField(verbose_name='接受者',max_length=20)
    receive_time = models.DateTimeField(verbose_name='接受时间', auto_now=True)
    activity=models.BooleanField(default=True)

    user_release_task=models.ForeignKey(UserInfo)

    class Meta:
        db_table='task_table'
