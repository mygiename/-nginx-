

from django.conf.urls import url

from . import views

urlpatterns=[
    # 登录
    url(r'^login$',views.login),
    # 注册
    url(r'^regist$',views.regist),
    #主页
    url(r'^homepage$', views.homepage),


    ]