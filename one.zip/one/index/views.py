import hashlib
import time

import jwt
from django.http import HttpResponse, JsonResponse
from django.shortcuts import render

# Create your views here.
from .models import UserInfo

# 加密
def mykey(password2):
    password1 = hashlib.md5()
    password1.update(password2.encode())
    return password1.hexdigest()

# 生成token
def mytoken(username, exp):
    key = '1234567ab'
    now_t = time.time()
    payload = {'username': username, 'exp': int(now_t + exp)}
    return jwt.encode(payload, key, algorithm='HS256')

def regist(request):
    '''
    返回注册页面/实现注册
    :param request:
    :return:
    '''
    if request.method=='GET':
        return render(request,'index/registor.html')

    elif request.method=='POST':
        username=request.POST.get('username')
        if username:
            if 'delete' in username or 'drop' in username or 'create' in username:
                return render(request,'index/tip.html',{'statu':'stack','message':'该用户已注测'})

            user=UserInfo.objects.filter(username=username)
            print(user)
            # 判断数据库中是否存在该用户名
            if user:
                return  render(request,'index/tip.html',{'statu': 'stack', 'message': '该用户已被注册'})
            password1=request.POST.get('password_1')
            password2=request.POST.get('password_2')

            if password1 != password2:
                return render(request,'index/tip.html',{'statu': 'not p', 'message': '两次密码不相等'})
            if password1:
                if 'delete' in password1 or 'drop' in password1 or 'create' in password1:
                    return render(request,'index/tip.html',{'statu': 'stack', 'message': '该用户已被注册'})

            # 密码加密
            passwordx=mykey(password2)
            UserInfo.objects.create(username=username,password=passwordx)
        return render(request,'index/tip.html',{'statu': 'success', 'message': '已完成注册,将前往登录页面'})


def login(request):
    '''
    返回登录/主页面
    :param request:
    :return:
    '''
    if request.method=='GET':
        return render(request,'index/login.html')
    elif request.method=='POST':
        # 验证账号密码是否正确
        username=request.POST.get('username')
        if 'delete' in username or 'drop' in username or 'create' in username:
            return render(request,'index/tip.html',{'statu':'zhudefault','message':'用户名或密码错误请重新登录'})
        user = UserInfo.objects.filter(username=username)
        password = request.POST.get('password')
        ps1=mykey(password)
        # user是queryset对象,其中的第一个要先取出其中的用户表对象
        if user:
            # 验证密码
            if ps1==user[0].password:
                # 返回token,返回约定,跳转页面
                token=mytoken(username,60*60*3)
                return render(request,'index/homepage.html',{'mytoken':token,'message':'ok'})

    return HttpResponse('我想对你说: 警告一次,第二次法庭见!!!')


def homepage(request):


    return render(request,'index/homepage.html')